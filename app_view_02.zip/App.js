import React from 'react'
import {View, Text} from 'react-native';

function App(){
  return(
    <View style={{backgroundColor:'green', alignItems:'center', paddingTop:'20px'}}>
        <View style={{backgroundColor:'red', height:'20%', width:'90%', borderTopLeftRadius:'25px', borderTopRightRadius:'25px', borderColor: 'black', borderWidth: 5,  }}>
          <Text style={{ textAlign: 'center', fontWeight: 'bold' }} >COMPONENTE VIEW</Text>
        </View>
        <View style={{backgroundColor:'yellow' , height:'60%',  width:'90%', marginTop:'20px', borderColor: 'black', borderWidth: 5}}>
          <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>CONTEÚDO</Text>
        </View>
        <View style={{backgroundColor:'gray' , height:'10%',  width:'90%', marginTop:'20px', borderBottomLeftRadius:'25px', borderBottomRightRadius:'25px', borderColor: 'black', borderWidth: 5}}>
          <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>GIULIA DE BARROS</Text>
          <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>27/02/2026</Text>
        </View>
    </View>
  );
}export default App;